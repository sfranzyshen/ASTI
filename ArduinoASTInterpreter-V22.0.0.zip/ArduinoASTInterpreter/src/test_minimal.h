/**
 * Test header
 * Version: 1.0.0
 */
#pragma once
#define TEST_VERSION "1.0.0"
